# To override execution user:group webstats:webstats, add --build-arg OSUSER="yankee" --build-arg OSGROUP="doddle" 
docker build -t webstats-server .
